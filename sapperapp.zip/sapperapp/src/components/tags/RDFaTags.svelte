<!--
@file FIXME
-->

<section vocab="http://schema.org/" typeof="Service">
    <meta property="serviceType" content="Leadership Coaching"/>
    <span property="areaServed" typeof="Country">
        <meta property="name" content="United Kingdom"/>
    </span>
    <span property="areaServed" typeof="Country">
        <meta property="name" content="Sweden"/>
    </span>
    <span property="areaServed" typeof="Country">
        <meta property="name" content="Belgium"/>
    </span>
    <span property="areaServed" typeof="Country">
        <meta property="name" content="Finland"/>
    </span>
    <span property="areaServed" typeof="Country">
        <meta property="name" content="Denmark"/>
    </span>
    <span property="areaServed" typeof="Country">
        <meta property="name" content="Norway"/>
    </span>
    <span property="areaServed" typeof="Country">
        <meta property="name" content="Germany"/>
    </span>
    <span property="areaServed" typeof="Country">
        <meta property="name" content="France"/>
    </span>

    <section property="provider" typeof="Person">

        <section property="address" typeof="PostalAddress">

            <meta property="addressLocality" content="Paris"/>

            <section property="addressCountry" typeof="Country">
                <meta property="name" content="France"/>
            </section>

        </section>

        <meta property="email" content="emanuele@emanuelesantanche.com"/>

        <section property="address" typeof="PostalAddress">

            <meta property="addressLocality" content="Paris"/>

            <section property="addressCountry" typeof="Country">
                <meta property="name" content="France"/>
            </section>

        </section>

        <meta property="telephone" content="+33644755879"/>

        <meta property="name" content="Emanuele Santanche"/>
    </section>
</section>
