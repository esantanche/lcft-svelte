<!--
@file FIXME Utility function to convert a title to a slug.
The title belongs to an item. The slug is what we add to the url of the item to
help search engines to index the item's page.
-->

<style>

    .spacerpane {
        height: 11vh;
    }

</style>

<div class="spacerpane" >
    <slot></slot>
</div>