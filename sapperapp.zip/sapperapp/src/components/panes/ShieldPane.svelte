<!--
@file FIXME Utility function to convert a title to a slug.
The title belongs to an item. The slug is what we add to the url of the item to
help search engines to index the item's page.
-->

<style>
    .shieldpane {
        width: 200px;
        margin-left: auto;
        margin-right: auto;
        margin-bottom: 6vh;
    }
</style>

<div class="shieldpane">
    <slot></slot>
</div>
