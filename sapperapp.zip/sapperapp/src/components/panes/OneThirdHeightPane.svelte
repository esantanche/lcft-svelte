<!--
@file FIXME Utility function to convert a title to a slug.
The title belongs to an item. The slug is what we add to the url of the item to
help search engines to index the item's page.
-->

<style>

    .onethirdheightpane {
        height: 33vh;
    }

</style>

<div class="onethirdheightpane" >
    <slot></slot>
</div>