<!--
@file FIXME Utility function to convert a title to a slug.
The title belongs to an item. The slug is what we add to the url of the item to
help search engines to index the item's page.
-->

<style>

    .centeringpane {
        display: flex;
        flex-direction: column;
        align-items: center;
    }

</style>

<div class="centeringpane" >
    <slot></slot>
</div>