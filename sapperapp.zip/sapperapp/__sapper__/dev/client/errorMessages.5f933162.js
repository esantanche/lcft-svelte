/**
 * Obtaining a human readable error message from an error object.
 *
 * @param {object} error An error object. Many exception handling processes return such an object.
 * @returns {string} The error message
 */
function error_message_from_error(error) {

    if (error.status) {

        // In this case the error is a response from http query performed using a fetch instruction

        return "status: " + error.status + " --- statusText: " + error.statusText + " --- url: " + error.url;

    } else {

        // Here there may be other ways to convert error to text according to other types of errors

        return "";
    }

}

export { error_message_from_error as e };
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiZXJyb3JNZXNzYWdlcy41ZjkzMzE2Mi5qcyIsInNvdXJjZXMiOlsiLi4vLi4vLi4vc3JjL2hlbHBlcnMvZXJyb3JNZXNzYWdlcy5qcyJdLCJzb3VyY2VzQ29udGVudCI6WyIvKipcbiAqIE9idGFpbmluZyBhIGh1bWFuIHJlYWRhYmxlIGVycm9yIG1lc3NhZ2UgZnJvbSBhbiBlcnJvciBvYmplY3QuXG4gKlxuICogQHBhcmFtIHtvYmplY3R9IGVycm9yIEFuIGVycm9yIG9iamVjdC4gTWFueSBleGNlcHRpb24gaGFuZGxpbmcgcHJvY2Vzc2VzIHJldHVybiBzdWNoIGFuIG9iamVjdC5cbiAqIEByZXR1cm5zIHtzdHJpbmd9IFRoZSBlcnJvciBtZXNzYWdlXG4gKi9cbmV4cG9ydCBmdW5jdGlvbiBlcnJvcl9tZXNzYWdlX2Zyb21fZXJyb3IoZXJyb3IpIHtcblxuICAgIGlmIChlcnJvci5zdGF0dXMpIHtcblxuICAgICAgICAvLyBJbiB0aGlzIGNhc2UgdGhlIGVycm9yIGlzIGEgcmVzcG9uc2UgZnJvbSBodHRwIHF1ZXJ5IHBlcmZvcm1lZCB1c2luZyBhIGZldGNoIGluc3RydWN0aW9uXG5cbiAgICAgICAgcmV0dXJuIFwic3RhdHVzOiBcIiArIGVycm9yLnN0YXR1cyArIFwiIC0tLSBzdGF0dXNUZXh0OiBcIiArIGVycm9yLnN0YXR1c1RleHQgKyBcIiAtLS0gdXJsOiBcIiArIGVycm9yLnVybDtcblxuICAgIH0gZWxzZSB7XG5cbiAgICAgICAgLy8gSGVyZSB0aGVyZSBtYXkgYmUgb3RoZXIgd2F5cyB0byBjb252ZXJ0IGVycm9yIHRvIHRleHQgYWNjb3JkaW5nIHRvIG90aGVyIHR5cGVzIG9mIGVycm9yc1xuXG4gICAgICAgIHJldHVybiBcIlwiO1xuICAgIH1cblxufVxuIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNPLFNBQVMsd0JBQXdCLENBQUMsS0FBSyxFQUFFO0FBQ2hEO0FBQ0EsSUFBSSxJQUFJLEtBQUssQ0FBQyxNQUFNLEVBQUU7QUFDdEI7QUFDQTtBQUNBO0FBQ0EsUUFBUSxPQUFPLFVBQVUsR0FBRyxLQUFLLENBQUMsTUFBTSxHQUFHLG1CQUFtQixHQUFHLEtBQUssQ0FBQyxVQUFVLEdBQUcsWUFBWSxHQUFHLEtBQUssQ0FBQyxHQUFHLENBQUM7QUFDN0c7QUFDQSxLQUFLLE1BQU07QUFDWDtBQUNBO0FBQ0E7QUFDQSxRQUFRLE9BQU8sRUFBRSxDQUFDO0FBQ2xCLEtBQUs7QUFDTDtBQUNBOzs7OyJ9
